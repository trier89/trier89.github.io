﻿@echo off
chcp 65001 >nul
title RevitDxfTo3D 설치 (Revit 2024)
echo ============================================
echo    RevitDxfTo3D  -  Revit 2024 설치
echo ============================================
echo.
echo 파일을 복사하고 차단을 해제합니다...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -RevitVersion 2024
echo.
echo ============================================
echo  설치가 끝났습니다. Revit 2024 을(를) 재시작하세요.
echo  애드인 탭에 'DXF - 3D' 패널이 나타납니다.
echo ============================================
echo.
pause
