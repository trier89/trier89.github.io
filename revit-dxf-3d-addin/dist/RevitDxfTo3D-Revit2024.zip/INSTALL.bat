@echo off
chcp 65001 >nul
title RevitDxfTo3D Installer (Revit 2024)
echo.
echo   RevitDxfTo3D  -  Revit 2024  Install
echo   -------------------------------------
echo   Copying files and unblocking (Mark-of-the-Web)...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -RevitVersion 2024
echo.
echo   Done. Please RESTART Revit 2024.
echo   Look for the 'DXF - 3D' panel on the Add-Ins ribbon tab.
echo.
pause
